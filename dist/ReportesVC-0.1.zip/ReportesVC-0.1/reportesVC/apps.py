from django.apps import AppConfig

class ReporteVCConfig(AppConfig):
    name = 'reportesContravel.reportesVC'
